<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sql_injection_lab";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Database connected successfully!";
?>
